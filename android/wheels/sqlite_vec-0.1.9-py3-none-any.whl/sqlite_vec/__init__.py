"""Resolver stub. sqlite-vec is never imported on the phone: langgraph's SqliteSaver
works without the extension, verified by importing langgraph.checkpoint.sqlite and
all three of its submodules with sqlite_vec blocked (see android/wheels/BUILD.md).

This module raises if anything ever does import it, so a future code path reaching
for the extension fails loudly instead of silently running without it.
"""

raise ImportError(
    "sqlite_vec is a resolver stub on this installation; the native extension "
    "was deliberately not shipped (android/wheels/BUILD.md)"
)
